# AXIOM ELIMINATION STRATEGIES
## Complete Proof Patterns for Remaining 17 Axioms

**Generated**: 2026-01-25
**Status**: Detailed proof strategies with code templates

---

## CATEGORY 1: Typing Rule Axioms (Should be DEFINITIONS)

### AX-T1: T_Loc
```coq
(* CURRENT (WRONG - axiom) *)
Axiom T_Loc : forall Γ Σ Δ l T lab,
  Σ_lookup l Σ = Some (T, lab) ->
  has_type Γ Σ Δ (ELoc l) (TRef T lab) EFF_Pure.

(* FIX: This should be a typing rule constructor, not axiom *)
(* In Typing.v, add: *)
| T_Loc : forall Γ Σ Δ l T lab,
    Σ_lookup l Σ = Some (T, lab) ->
    has_type Γ Σ Δ (ELoc l) (TRef T lab) EFF_Pure

(* EFFORT: 15 minutes - just move from axiom to inductive *)
```

### AX-T2: T_Assign
```coq
(* CURRENT (WRONG - axiom) *)
Axiom T_Assign : forall Γ Σ Δ e1 e2 T lab ε1 ε2,
  has_type Γ Σ Δ e1 (TRef T lab) ε1 ->
  has_type Γ Σ Δ e2 T ε2 ->
  has_type Γ Σ Δ (EAssign e1 e2) TUnit (EFF_Union (EFF_Write lab) (EFF_Union ε1 ε2)).

(* FIX: Move to typing rules in Typing.v *)
| T_Assign : forall Γ Σ Δ e1 e2 T lab ε1 ε2,
    has_type Γ Σ Δ e1 (TRef T lab) ε1 ->
    has_type Γ Σ Δ e2 T ε2 ->
    has_type Γ Σ Δ (EAssign e1 e2) TUnit (EFF_Union (EFF_Write lab) (EFF_Union ε1 ε2))

(* EFFORT: 15 minutes *)
```

### AX-T3: has_type (in LogicalRelationDeref_PROOF_FINAL.v)
```coq
(* CURRENT (WRONG - axiom) *)
Axiom has_type : ctx -> store_typing -> lbl_ctx -> expr -> ty -> eff -> Prop.

(* FIX: Import from Typing.v instead *)
Require Import RIINA.foundations.Typing.
(* Then use the typing relation directly *)

(* EFFORT: 5 minutes - just change import *)
```

---

## CATEGORY 2: Expression Relation Axioms

### AX-E1: exp_rel_n_unfold
```coq
(* AXIOM *)
Axiom exp_rel_n_unfold : forall n Σ T e1 e2 σ1 σ2,
  exp_rel_n n Σ T e1 e2 ->
  store_rel_n n Σ σ1 σ2 ->
  forall v1 σ1',
    multi_step e1 σ1 v1 σ1' ->
    is_value v1 ->
    exists v2 σ2',
      multi_step e2 σ2 v2 σ2' /\
      is_value v2 /\
      val_rel_n n Σ T v1 v2 /\
      store_rel_n n Σ σ1' σ2'.

(* PROOF STRATEGY *)
Lemma exp_rel_n_unfold : forall n Σ T e1 e2 σ1 σ2,
  exp_rel_n n Σ T e1 e2 ->
  store_rel_n n Σ σ1 σ2 ->
  forall v1 σ1',
    multi_step e1 σ1 v1 σ1' ->
    is_value v1 ->
    exists v2 σ2',
      multi_step e2 σ2 v2 σ2' /\
      is_value v2 /\
      val_rel_n n Σ T v1 v2 /\
      store_rel_n n Σ σ1' σ2'.
Proof.
  intros n Σ T e1 e2 σ1 σ2 Hexp Hstore v1 σ1' Hstep Hval.
  (* exp_rel_n IS DEFINED as this property! Just unfold. *)
  unfold exp_rel_n in Hexp.
  apply Hexp; auto.
Qed.

(* EFFORT: 5 minutes if exp_rel_n is defined this way *)
(* If defined differently, need to prove equivalence *)
```

### AX-E2: exp_rel_n_unit
```coq
(* AXIOM *)
Axiom exp_rel_n_unit : forall n Σ,
  n > 0 ->
  exp_rel_n n Σ TUnit EUnit EUnit.

(* PROOF STRATEGY *)
Lemma exp_rel_n_unit : forall n Σ,
  n > 0 ->
  exp_rel_n n Σ TUnit EUnit EUnit.
Proof.
  intros n Σ Hgt.
  unfold exp_rel_n.
  intros s1 s2 Hstore v1 s1' Hstep Hval.
  (* EUnit is a value, so multi_step EUnit s EUnit s *)
  (* Need: multi_step e s1 v1 s1' with e = EUnit *)
  (* Since EUnit is a value, v1 = EUnit, s1' = s1 *)
  exists EUnit, s2.
  repeat split.
  - apply multi_refl. (* or your reflexivity lemma *)
  - constructor. (* is_value EUnit *)
  - apply val_rel_n_unit; auto.
  - (* store unchanged: s1' = s1, so store_rel_n n Σ s1 s2 *)
    (* Need to prove s1' = s1 from value stepping *)
    admit. (* Requires: value_no_step lemma *)
Abort.

(* PREREQUISITE: Need lemma that values don't step *)
Lemma value_multi_step_eq : forall v s v' s',
  is_value v ->
  multi_step v s v' s' ->
  v = v' /\ s = s'.

(* EFFORT: 30 minutes with prerequisite *)
```

### AX-E3: exp_rel_n_base
```coq
(* AXIOM *)
Axiom exp_rel_n_base : forall Σ T e1 e2,
  exp_rel_n 0 Σ T e1 e2.

(* PROOF - TRIVIAL *)
Lemma exp_rel_n_base : forall Σ T e1 e2,
  exp_rel_n 0 Σ T e1 e2.
Proof.
  intros Σ T e1 e2.
  unfold exp_rel_n.
  intros s1 s2 Hstore v1 s1' Hstep Hval.
  exists v1, s2.
  repeat split; auto.
  - (* Need to show e2 steps to something *)
    (* At step 0, this is trivial - we can pick any result *)
    admit. (* Depends on exp_rel_n definition at 0 *)
  - apply val_rel_n_zero.
Abort.

(* EFFORT: 15 minutes - depends on exact definition *)
```

### AX-E4: exp_rel_n_step_down
```coq
(* AXIOM *)
Axiom exp_rel_n_step_down : forall n m Σ T e1 e2,
  m <= n ->
  exp_rel_n n Σ T e1 e2 ->
  exp_rel_n m Σ T e1 e2.

(* PROOF STRATEGY *)
Lemma exp_rel_n_step_down : forall n m Σ T e1 e2,
  m <= n ->
  exp_rel_n n Σ T e1 e2 ->
  exp_rel_n m Σ T e1 e2.
Proof.
  intros n m Σ T e1 e2 Hle Hexp.
  unfold exp_rel_n in *.
  intros s1 s2 Hstore v1 s1' Hstep Hval.
  (* Need store_rel_n n from store_rel_n m *)
  assert (Hstore' : store_rel_n n Σ s1 s2).
  { apply store_rel_n_step_up with (m := m); auto. }
  (* But wait - we need step UP, not step down! *)
  (* This is the HARD direction *)
  (* Alternative: weaken the result *)
  specialize (Hexp s1 s2 Hstore' v1 s1' Hstep Hval).
  destruct Hexp as [v2 [s2' [Hstep2 [Hval2 [Hvrel Hsrel]]]]].
  exists v2, s2'.
  repeat split; auto.
  - apply val_rel_n_step_down with (n := n); auto.
  - apply store_rel_n_step_down with (n := n); auto.
Qed.

(* DEPENDENCY: store_rel_n_step_up (harder than step_down) *)
(* EFFORT: 2-4 hours including dependencies *)
```

---

## CATEGORY 3: Store Axioms

### AX-S1: store_contains_values
```coq
(* AXIOM *)
Axiom store_contains_values : forall l s v,
  store_lookup l s = Some v -> is_value v.

(* PROOF STRATEGY *)
(* This is an INVARIANT that must be maintained by evaluation *)
(* It's not provable from definitions alone - need to prove *)
(* store_well_typed_invariant: evaluation preserves well-typed stores *)

(* APPROACH: Make it a hypothesis of exp_rel_n, or prove preservation *)
Lemma store_contains_values : forall Σ s,
  store_well_typed Σ s ->
  forall l v, store_lookup l s = Some v -> is_value v.
Proof.
  intros Σ s Hwt l v Hlook.
  unfold store_well_typed in Hwt.
  (* Depends on how store_well_typed is defined *)
  (* If it says "all stored values are values", direct *)
  admit.
Abort.

(* EFFORT: 1-2 hours - requires store invariant infrastructure *)
```

### AX-S2: store_rel_same_domain
```coq
(* AXIOM *)
Axiom store_rel_same_domain : forall n Σ s1 s2 l T sl,
  store_rel_n n Σ s1 s2 ->
  store_ty_lookup l Σ = Some (T, sl) ->
  (exists v1, store_lookup l s1 = Some v1) ->
  exists v2, store_lookup l s2 = Some v2.

(* PROOF STRATEGY *)
(* This should follow from how stores are constructed *)
(* Related stores should have been built from same allocation sequence *)

Lemma store_rel_same_domain : forall n Σ s1 s2 l T sl,
  store_rel_n n Σ s1 s2 ->
  store_ty_lookup l Σ = Some (T, sl) ->
  (exists v1, store_lookup l s1 = Some v1) ->
  exists v2, store_lookup l s2 = Some v2.
Proof.
  intros n Σ s1 s2 l T sl Hrel Hty [v1 Hv1].
  (* If store_rel_n requires both stores to have same domain... *)
  (* This might need to be PART of store_rel_n definition *)
  admit.
Abort.

(* EFFORT: 1-2 hours - may require changing store_rel_n definition *)
```

### AX-S3: store_update_preserves_rel
```coq
(* AXIOM *)
Axiom store_update_preserves_rel : forall n Σ σ1 σ2 l T lab v1 v2,
  store_rel_n n Σ σ1 σ2 ->
  store_ty_lookup l Σ = Some (T, lab) ->
  val_rel_n n Σ T v1 v2 ->
  store_rel_n n Σ (store_update σ1 l v1) (store_update σ2 l v2).

(* PROOF STRATEGY *)
Lemma store_update_preserves_rel : forall n Σ σ1 σ2 l T lab v1 v2,
  store_rel_n n Σ σ1 σ2 ->
  store_ty_lookup l Σ = Some (T, lab) ->
  val_rel_n n Σ T v1 v2 ->
  store_rel_n n Σ (store_update σ1 l v1) (store_update σ2 l v2).
Proof.
  intros n Σ σ1 σ2 l T lab v1 v2 Hrel Hty Hvrel.
  unfold store_rel_n in *.
  intros l' T' sl' Hty' v1' v2' Hv1' Hv2'.
  destruct (Nat.eq_dec l l') as [Heq | Hneq].
  - (* l = l' : updated location *)
    subst l'.
    rewrite store_update_lookup_eq in Hv1'.
    rewrite store_update_lookup_eq in Hv2'.
    inversion Hv1'. inversion Hv2'. subst.
    (* Need: T' = T and sl' = lab *)
    rewrite Hty in Hty'. inversion Hty'. subst.
    exact Hvrel.
  - (* l <> l' : other location *)
    rewrite store_update_lookup_neq in Hv1'; auto.
    rewrite store_update_lookup_neq in Hv2'; auto.
    apply Hrel with (T := T') (sl := sl'); auto.
Qed.

(* EFFORT: 30 minutes - straightforward with store update lemmas *)
```

---

## CATEGORY 4: Fundamental Theorem (HARDEST)

### AX-F1: fundamental_theorem / fundamental_lemma
```coq
(* AXIOM *)
Axiom fundamental_theorem : forall Γ Σ Δ e T ε ρ1 ρ2,
  has_type Γ Σ Δ e T ε ->
  env_rel Σ Γ ρ1 ρ2 ->
  rho_no_free_all ρ1 ->
  rho_no_free_all ρ2 ->
  forall n, exp_rel_n n Σ T (subst_rho ρ1 e) (subst_rho ρ2 e).

(* PROOF STRATEGY: Induction on typing derivation *)
Theorem fundamental_theorem : forall Γ Σ Δ e T ε ρ1 ρ2,
  has_type Γ Σ Δ e T ε ->
  env_rel Σ Γ ρ1 ρ2 ->
  rho_no_free_all ρ1 ->
  rho_no_free_all ρ2 ->
  forall n, exp_rel_n n Σ T (subst_rho ρ1 e) (subst_rho ρ2 e).
Proof.
  intros Γ Σ Δ e T ε ρ1 ρ2 Htype.
  induction Htype; intros Henv Hcl1 Hcl2 n.
  - (* T_Unit *)
    apply exp_rel_n_unit. (* need n > 0 case *)
  - (* T_Bool *)
    apply exp_rel_n_bool.
  - (* T_Var *)
    (* Use env_rel to get related values *)
    unfold env_rel in Henv.
    (* ... *)
  - (* T_Lam *)
    (* Lambda case - most complex *)
    (* Need to show functions are related *)
    (* ... *)
  - (* T_App *)
    (* Use IH for function and argument *)
    (* ... *)
  - (* T_Ref *)
    apply logical_relation_ref; auto.
  - (* T_Deref *)
    apply logical_relation_deref; auto.
  - (* T_Assign *)
    apply logical_relation_assign; auto.
  (* ... many more cases ... *)
Abort.

(* EFFORT: 80-160 hours - this is THE main theorem *)
(* DEPENDENCIES: All other axioms must be eliminated first *)
```

---

## SUMMARY: Elimination Order

### Phase 1: Quick Wins (2-4 hours)
1. T_Loc → Move to typing rules
2. T_Assign → Move to typing rules
3. has_type → Change to import
4. exp_rel_n_base → Trivial at step 0
5. val_rel_n_unit (already done)
6. val_rel_n_ref (already done)
7. val_rel_n_step_down (already done)
8. store_rel_n_step_down (already done)

### Phase 2: Medium Effort (8-16 hours)
9. store_update_preserves_rel → Direct proof
10. exp_rel_n_unfold → Definition unfolding
11. store_contains_values → Store invariant
12. store_rel_same_domain → Domain invariant

### Phase 3: Hard (20-40 hours)
13. exp_rel_n_step_down → Needs step_up
14. deref_eval_structure → Evaluation analysis
15. val_rel_n_to_val_rel → Conversion

### Phase 4: Fundamental Theorem (80-160 hours)
16. fundamental_theorem → Main proof
17. All logical_relation_* → Cases of fundamental

---

## TRACKING CHECKLIST

```
[ ] T_Loc - convert to typing rule
[ ] T_Assign - convert to typing rule  
[ ] has_type - change to import
[x] val_rel_n_unit - DONE
[x] val_rel_n_bool - DONE
[x] val_rel_n_nat - DONE
[x] val_rel_n_ref - DONE
[x] val_rel_n_ref_same_loc - DONE
[x] val_rel_n_step_down - DONE
[x] val_rel_n_zero - DONE
[x] store_rel_n_step_down - DONE
[x] store_rel_n_zero - DONE
[ ] exp_rel_n_unfold
[ ] exp_rel_n_unit
[ ] exp_rel_n_base
[ ] exp_rel_n_step_down
[ ] store_contains_values
[ ] store_rel_same_domain
[ ] store_update_preserves_rel
[ ] fundamental_theorem
[ ] logical_relation_ref
[ ] logical_relation_deref
[ ] logical_relation_assign
[ ] logical_relation_declassify
[ ] val_rel_n_to_val_rel
```
