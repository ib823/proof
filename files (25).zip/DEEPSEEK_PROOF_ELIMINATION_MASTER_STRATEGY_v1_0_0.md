# DEEPSEEK PROOF ELIMINATION MASTER STRATEGY

## Version 1.0.0 — Complete Axiom and Admit Resolution

```
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                                      ║
║  DEEPSEEK PROOF ELIMINATION STRATEGY                                                                ║
║                                                                                                      ║
║  Target: Eliminate 15 Core Axioms + 49 Admits → 0                                                   ║
║  Method: Structured prompts for DeepSeek AI (Web)                                                   ║
║  Standard: ULTRA KIASU | ABSOLUTE PERFECTION | ZERO COMPROMISE                                      ║
║                                                                                                      ║
║  "Every axiom eliminated is a security guarantee proven."                                           ║
║                                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════════╝
```

---

# TABLE OF CONTENTS

1. [Strategy Overview](#part-i-strategy-overview)
2. [Master Context Prompt](#part-ii-master-context-prompt)
3. [Phase 1: Expression Relation Axioms](#part-iii-phase-1-expression-relation-axioms)
4. [Phase 2: Logical Relation Axioms](#part-iv-phase-2-logical-relation-axioms)
5. [Phase 3: Value/Store Relation Axioms](#part-v-phase-3-valuestore-relation-axioms)
6. [Phase 4: FundamentalTheorem.v Admits](#part-vi-phase-4-fundamentaltheoremv-admits)
7. [Phase 5: MasterTheorem.v Admits](#part-vii-phase-5-mastertheoremv-admits)
8. [Verification Protocol](#part-viii-verification-protocol)
9. [Troubleshooting Prompts](#part-ix-troubleshooting-prompts)

---

# PART I: STRATEGY OVERVIEW

## 1.1 What Must Be Eliminated

| Category | Count | Files | Priority |
|----------|-------|-------|----------|
| Expression Relation Axioms | 7 | Various | P0 |
| Logical Relation Axioms | 4 | Various | P0 |
| Value/Store Relation Axioms | 4 | Various | P0 |
| FundamentalTheorem.v Admits | ~25 | FundamentalTheorem.v | P1 |
| MasterTheorem.v Admits | ~24 | MasterTheorem.v | P1 |
| **TOTAL** | **64** | | |

## 1.2 DeepSeek Chat Strategy

```
RECOMMENDED APPROACH:
├── Chat 1: Master Context + Expression Relations (7 axioms)
├── Chat 2: Logical Relations (4 axioms)
├── Chat 3: Value/Store Relations (4 axioms)
├── Chat 4: FundamentalTheorem.v Admits (Part 1)
├── Chat 5: FundamentalTheorem.v Admits (Part 2)
├── Chat 6: MasterTheorem.v Admits (Part 1)
├── Chat 7: MasterTheorem.v Admits (Part 2)
└── Chat 8: Verification and Fixes
```

## 1.3 Critical Instructions for DeepSeek

Before each prompt, ensure DeepSeek understands:

1. **Output Format**: Complete, compilable Coq code only
2. **No Placeholders**: Every proof must be complete, no `admit`, no `Admitted`
3. **No Shortcuts**: Full proofs using proper Coq tactics
4. **Verification**: Code must compile with `coqc`

---

# PART II: MASTER CONTEXT PROMPT

## 2.1 Use This as First Message in EVERY DeepSeek Chat

```
=== DEEPSEEK PROMPT: MASTER CONTEXT ===

You are an expert Coq proof assistant specializing in step-indexed logical relations for type safety proofs. I am working on TERAS-LANG, a security-focused programming language with:

- Linear types (resources used exactly once)
- Effect system (algebraic effects with handlers)
- Information flow control (security labels, non-interference)
- Dependent types (first-order)

The proof architecture uses STEP-INDEXED LOGICAL RELATIONS with these key definitions:

```coq
(* Step-indexed value relation *)
Fixpoint val_rel (n : nat) (Σ : store_typing) (T : type) (v1 v2 : value) : Prop :=
  match n with
  | 0 => True  (* Base case: trivially related at step 0 *)
  | S m => 
    match T with
    | TUnit => v1 = VUnit /\ v2 = VUnit
    | TBool => exists b, v1 = VBool b /\ v2 = VBool b
    | TInt => exists i, v1 = VInt i /\ v2 = VInt i
    | TProd T1 T2 => 
        exists v1a v1b v2a v2b,
        v1 = VPair v1a v1b /\ v2 = VPair v2a v2b /\
        val_rel m Σ T1 v1a v2a /\ val_rel m Σ T2 v1b v2b
    | TArrow T1 eff T2 =>
        exists e1 e2,
        v1 = VLam e1 /\ v2 = VLam e2 /\
        forall k (Hk : k < S m) Σ' (Hext : store_extends Σ Σ') v1' v2',
          val_rel k Σ' T1 v1' v2' ->
          exp_rel k Σ' T2 (subst v1' e1) (subst v2' e2)
    (* ... other cases ... *)
    end
  end.

(* Step-indexed expression relation *)
Definition exp_rel (n : nat) (Σ : store_typing) (T : type) (e1 e2 : expr) : Prop :=
  forall k (Hk : k <= n) σ1 σ2,
    store_rel k Σ σ1 σ2 ->
    (terminates_in k e1 σ1 -> terminates_in k e2 σ2) /\
    (forall v1 σ1' j,
      steps_to j e1 σ1 v1 σ1' -> j < k ->
      exists v2 σ2' Σ',
        steps_to j e2 σ2 v2 σ2' /\
        store_extends Σ Σ' /\
        store_rel (k - j) Σ' σ1' σ2' /\
        val_rel (k - j) Σ' T v1 v2).

(* Store relation *)
Definition store_rel (n : nat) (Σ : store_typing) (σ1 σ2 : store) : Prop :=
  forall l T,
    Σ l = Some T ->
    exists v1 v2,
      σ1 l = Some v1 /\ σ2 l = Some v2 /\
      val_rel n Σ T v1 v2.
```

KEY PROOF TECHNIQUES I need you to use:

1. **Step-down induction**: When proving for step n, use IH at step (n-1) or (k-1)
2. **Store extension**: Use `store_extends_refl`, `store_extends_trans`
3. **Monotonicity**: `val_rel_mono` - if val_rel holds at n, it holds at m < n
4. **Anti-reduction**: `exp_rel` is closed under reduction
5. **Compatibility lemmas**: Each expression form has a compatibility lemma

CRITICAL REQUIREMENTS:
- Output COMPLETE Coq proofs with NO admits, NO Admitted, NO placeholders
- Use standard Coq tactics: intros, destruct, induction, apply, eapply, exact, auto, omega/lia
- Every proof must COMPILE with coqc
- Follow the exact structure of existing proofs in the codebase

I will now give you specific axioms to prove. For each axiom:
1. Show me the complete proof
2. Explain the proof strategy briefly
3. Ensure it compiles

Ready? I will provide the first axiom.
```

---

# PART III: PHASE 1 — EXPRESSION RELATION AXIOMS (7 Axioms)

## 3.1 Prompt for exp_rel_step1_app

```
=== DEEPSEEK PROMPT: exp_rel_step1_app ===

Prove this axiom about step-indexed expression relations for function application:

```coq
Axiom exp_rel_step1_app : forall n Σ T1 T2 eff e1 e2 e1' e2',
  exp_rel n Σ (TArrow T1 eff T2) e1 e2 ->
  exp_rel n Σ T1 e1' e2' ->
  exp_rel n Σ T2 (EApp e1 e1') (EApp e2 e2').
```

Context:
- `EApp e1 e2` is function application
- `TArrow T1 eff T2` is function type from T1 to T2 with effect eff
- `exp_rel n Σ T e1 e2` means e1 and e2 are related at type T for n steps under store typing Σ

Proof strategy hints:
1. Unfold exp_rel definition
2. Introduce k, Hk, σ1, σ2, Hstore
3. For termination: compose termination of function and argument
4. For value case: 
   - Get v1_fn from e1, v2_fn from e2 (function values)
   - Get v1_arg from e1', v2_arg from e2' (argument values)
   - Apply val_rel at arrow type to get body relation
   - Use substitution to get result

Provide the COMPLETE Coq proof with Qed at the end. No admits.
```

## 3.2 Prompt for exp_rel_step1_let

```
=== DEEPSEEK PROMPT: exp_rel_step1_let ===

Prove this axiom about step-indexed expression relations for let bindings:

```coq
Axiom exp_rel_step1_let : forall n Σ T1 T2 e1 e2 e1' e2',
  exp_rel n Σ T1 e1 e2 ->
  (forall v1 v2, val_rel n Σ T1 v1 v2 -> 
   exp_rel n Σ T2 (subst v1 e1') (subst v2 e2')) ->
  exp_rel n Σ T2 (ELet e1 e1') (ELet e2 e2').
```

Context:
- `ELet e body` binds result of e in body
- The second premise is a compatibility condition for the body

Proof strategy:
1. Unfold exp_rel
2. Use IH from first premise to get value from e1/e2
3. Apply second premise with those values
4. Compose step counts correctly

Provide the COMPLETE Coq proof. No admits.
```

## 3.3 Prompt for exp_rel_step1_if

```
=== DEEPSEEK PROMPT: exp_rel_step1_if ===

Prove this axiom for conditional expressions:

```coq
Axiom exp_rel_step1_if : forall n Σ T e_cond1 e_cond2 e_then1 e_then2 e_else1 e_else2,
  exp_rel n Σ TBool e_cond1 e_cond2 ->
  exp_rel n Σ T e_then1 e_then2 ->
  exp_rel n Σ T e_else1 e_else2 ->
  exp_rel n Σ T (EIf e_cond1 e_then1 e_else1) (EIf e_cond2 e_then2 e_else2).
```

Context:
- `EIf cond then_branch else_branch` is conditional
- Condition must be boolean
- Both branches must have same type T

Proof strategy:
1. Evaluate condition to boolean value
2. Both sides get SAME boolean (from val_rel at TBool)
3. If true: use then branch relation
4. If false: use else branch relation
5. Careful step counting

Provide the COMPLETE Coq proof. No admits.
```

## 3.4 Prompt for exp_rel_step1_case

```
=== DEEPSEEK PROMPT: exp_rel_step1_case ===

Prove this axiom for sum type case analysis:

```coq
Axiom exp_rel_step1_case : forall n Σ T1 T2 T e1 e2 e_left1 e_left2 e_right1 e_right2,
  exp_rel n Σ (TSum T1 T2) e1 e2 ->
  (forall v1 v2, val_rel n Σ T1 v1 v2 -> 
   exp_rel n Σ T (subst v1 e_left1) (subst v2 e_left2)) ->
  (forall v1 v2, val_rel n Σ T2 v1 v2 -> 
   exp_rel n Σ T (subst v1 e_right1) (subst v2 e_right2)) ->
  exp_rel n Σ T (ECase e1 e_left1 e_right1) (ECase e2 e_left2 e_right2).
```

Context:
- `ECase e left_branch right_branch` is sum elimination
- `TSum T1 T2` is sum type (Either/union)
- Left branch handles Inl, right branch handles Inr

Proof strategy:
1. Evaluate scrutinee e1/e2 to sum values
2. From val_rel at TSum, both are Inl or both are Inr (same constructor)
3. If Inl: apply left branch compatibility
4. If Inr: apply right branch compatibility

Provide the COMPLETE Coq proof. No admits.
```

## 3.5 Prompt for exp_rel_step1_fst and exp_rel_step1_snd

```
=== DEEPSEEK PROMPT: exp_rel_step1_fst and exp_rel_step1_snd ===

Prove these two axioms for product projections:

```coq
Axiom exp_rel_step1_fst : forall n Σ T1 T2 e1 e2,
  exp_rel n Σ (TProd T1 T2) e1 e2 ->
  exp_rel n Σ T1 (EFst e1) (EFst e2).

Axiom exp_rel_step1_snd : forall n Σ T1 T2 e1 e2,
  exp_rel n Σ (TProd T1 T2) e1 e2 ->
  exp_rel n Σ T2 (ESnd e1) (ESnd e2).
```

Context:
- `EFst e` projects first component of pair
- `ESnd e` projects second component
- `TProd T1 T2` is product type

Proof strategy (for fst, snd is symmetric):
1. Evaluate e1/e2 to pair values VPair v1a v1b / VPair v2a v2b
2. From val_rel at TProd, get val_rel for components
3. Fst evaluates to v1a/v2a which are related at T1
4. Return the component relation

Provide COMPLETE Coq proofs for BOTH. No admits.
```

## 3.6 Prompt for exp_rel_step1_handle

```
=== DEEPSEEK PROMPT: exp_rel_step1_handle ===

Prove this axiom for effect handlers:

```coq
Axiom exp_rel_step1_handle : forall n Σ T eff e1 e2 h1 h2,
  exp_rel n Σ T e1 e2 ->
  handler_rel n Σ eff T h1 h2 ->
  exp_rel n Σ T (EHandle e1 h1) (EHandle e2 h2).
```

Where handler_rel is defined as:
```coq
Definition handler_rel n Σ eff T h1 h2 :=
  forall op T_arg T_ret,
    eff_has_op eff op T_arg T_ret ->
    forall v1 v2 k1 k2,
      val_rel n Σ T_arg v1 v2 ->
      (forall v1' v2', val_rel n Σ T_ret v1' v2' -> 
       exp_rel n Σ T (k1 v1') (k2 v2')) ->
      exp_rel n Σ T (apply_handler h1 op v1 k1) (apply_handler h2 op v2 k2).
```

Context:
- `EHandle e h` runs e with effect handler h
- Handler catches effect operations and provides implementations
- Continuation k represents rest of computation

Proof strategy:
1. If e1/e2 terminate without effects: use exp_rel directly
2. If e1/e2 perform effect op with argument v:
   - Both perform SAME operation (from exp_rel)
   - Apply handler_rel to get related handler applications
   - Continue with continuation relation

This is the most complex proof. Provide COMPLETE Coq code. No admits.
```

---

# PART IV: PHASE 2 — LOGICAL RELATION AXIOMS (4 Axioms)

## 4.1 Prompt for logical_relation_ref

```
=== DEEPSEEK PROMPT: logical_relation_ref ===

Prove this axiom for reference creation:

```coq
Axiom logical_relation_ref : forall n Σ T e1 e2,
  exp_rel n Σ T e1 e2 ->
  exp_rel n Σ (TRef T) (ERef e1) (ERef e2).
```

Context:
- `ERef e` creates a new reference containing value of e
- `TRef T` is reference type
- References get fresh locations in the store

Proof strategy:
1. Evaluate e1/e2 to values v1/v2
2. Allocate fresh locations l1/l2 in stores
3. Extend store typing Σ to Σ' with l1 : T, l2 : T
4. Show val_rel at TRef: locations l1/l2 are related because they point to related values
5. Store relation extended correctly

Key lemmas needed:
- store_extends with new location
- fresh location not in domain
- val_rel at TRef defined as: same location maps to related values

Provide COMPLETE Coq proof. No admits.
```

## 4.2 Prompt for logical_relation_deref

```
=== DEEPSEEK PROMPT: logical_relation_deref ===

Prove this axiom for dereference:

```coq
Axiom logical_relation_deref : forall n Σ T e1 e2,
  exp_rel n Σ (TRef T) e1 e2 ->
  exp_rel n Σ T (EDeref e1) (EDeref e2).
```

Context:
- `EDeref e` reads the value at reference e
- Must look up location in store

Proof strategy:
1. Evaluate e1/e2 to location values VLoc l1 / VLoc l2
2. From val_rel at TRef, l1 and l2 map to related values in stores
3. Deref looks up stores: σ1(l1) = v1, σ2(l2) = v2
4. From store_rel, these values are related at T
5. Return the value relation

Provide COMPLETE Coq proof. No admits.
```

## 4.3 Prompt for logical_relation_assign

```
=== DEEPSEEK PROMPT: logical_relation_assign ===

Prove this axiom for reference assignment:

```coq
Axiom logical_relation_assign : forall n Σ T e_ref1 e_ref2 e_val1 e_val2,
  exp_rel n Σ (TRef T) e_ref1 e_ref2 ->
  exp_rel n Σ T e_val1 e_val2 ->
  exp_rel n Σ TUnit (EAssign e_ref1 e_val1) (EAssign e_ref2 e_val2).
```

Context:
- `EAssign ref val` updates reference to new value
- Returns unit
- Must update store relation

Proof strategy:
1. Evaluate e_ref1/e_ref2 to locations l1/l2
2. Evaluate e_val1/e_val2 to values v1/v2
3. Update stores: σ1' = σ1[l1 := v1], σ2' = σ2[l2 := v2]
4. Show store_rel preserved: l1/l2 now map to v1/v2 which are related
5. Return unit values (trivially related)

Provide COMPLETE Coq proof. No admits.
```

## 4.4 Prompt for logical_relation_declassify

```
=== DEEPSEEK PROMPT: logical_relation_declassify ===

Prove this axiom for declassification:

```coq
Axiom logical_relation_declassify : forall n Σ l_from l_to T e1 e2,
  exp_rel n Σ (TLabeled l_from T) e1 e2 ->
  can_declassify l_from l_to ->
  exp_rel n Σ (TLabeled l_to T) (EDeclassify l_to e1) (EDeclassify l_to e2).
```

Context:
- `EDeclassify l e` downgrades security label of e to l
- `TLabeled l T` is type T at security level l
- `can_declassify l_from l_to` is authorization check

Proof strategy:
1. Evaluate e1/e2 to labeled values VLabeled l_from v1 / VLabeled l_from v2
2. From val_rel at TLabeled l_from T, underlying values v1/v2 are related at T
3. Declassify produces VLabeled l_to v1 / VLabeled l_to v2
4. These are related at TLabeled l_to T (same underlying value relation)

Provide COMPLETE Coq proof. No admits.
```

---

# PART V: PHASE 3 — VALUE/STORE RELATION AXIOMS (4 Axioms)

## 5.1 Prompt for val_rel_n_step_up

```
=== DEEPSEEK PROMPT: val_rel_n_step_up ===

Prove this critical step-up lemma:

```coq
Axiom val_rel_n_step_up : forall n Σ T v1 v2,
  first_order_type T ->
  val_rel n Σ T v1 v2 ->
  val_rel (S n) Σ T v1 v2.
```

Context:
- First-order types: TUnit, TBool, TInt, TProd of FO, TSum of FO
- NOT first-order: TArrow (functions), TForall (polymorphism)
- This says: for first-order types, relation at n implies relation at n+1

Proof strategy (by induction on T being first-order):
1. Base cases (TUnit, TBool, TInt): val_rel is equality, trivially step-independent
2. TProd T1 T2: 
   - val_rel at n gives related components
   - IH on T1, T2 to step up components
   - Reassemble at n+1
3. TSum T1 T2: similar, case on Inl/Inr

Key insight: First-order types have no functions, so no step-indexed behavior in their structure.

Provide COMPLETE Coq proof. No admits.
```

## 5.2 Prompt for val_rel_n_lam_cumulative

```
=== DEEPSEEK PROMPT: val_rel_n_lam_cumulative ===

Prove this lambda cumulative lemma:

```coq
Axiom val_rel_n_lam_cumulative : forall n m Σ T1 eff T2 e1 e2,
  m <= n ->
  val_rel n Σ (TArrow T1 eff T2) (VLam e1) (VLam e2) ->
  val_rel m Σ (TArrow T1 eff T2) (VLam e1) (VLam e2).
```

Context:
- val_rel at arrow type means: for all related arguments, bodies are exp_rel
- This is DOWNWARD closure: relation at n implies relation at m <= n

Proof strategy:
1. Unfold val_rel at TArrow
2. n-relation says: forall k < n, ... exp_rel k ...
3. For m <= n: forall k < m, we have k < n, so use n-relation
4. This is monotonicity of step-indexing

Provide COMPLETE Coq proof. No admits.
```

## 5.3 Prompt for val_rel_n_to_val_rel and val_rel_at_type_to_val_rel_ho

```
=== DEEPSEEK PROMPT: val_rel conversions ===

Prove these two conversion lemmas:

```coq
Axiom val_rel_n_to_val_rel : forall n Σ T v1 v2,
  val_rel (S n) Σ T v1 v2 ->
  val_rel n Σ T v1 v2.

Axiom val_rel_at_type_to_val_rel_ho : forall n Σ T v1 v2,
  higher_order_type T ->
  val_rel n Σ T v1 v2 ->
  forall m, m <= n -> val_rel m Σ T v1 v2.
```

Context:
- First lemma: step-down (S n → n)
- Second lemma: monotonicity for higher-order types

Proof strategy for val_rel_n_to_val_rel:
1. By induction on type T
2. For each case, show S n relation implies n relation
3. Arrow case: uses that exp_rel is monotonic

Proof strategy for val_rel_at_type_to_val_rel_ho:
1. Higher-order types contain arrows
2. Unfold and use monotonicity of exp_rel
3. May need induction on type structure

Provide COMPLETE Coq proofs for BOTH. No admits.
```

## 5.4 Prompt for store_rel_n_step_up

```
=== DEEPSEEK PROMPT: store_rel_n_step_up ===

Prove this store relation step-up:

```coq
Axiom store_rel_n_step_up : forall n Σ σ1 σ2,
  (forall l T, Σ l = Some T -> first_order_type T) ->
  store_rel n Σ σ1 σ2 ->
  store_rel (S n) Σ σ1 σ2.
```

Context:
- If all types in store typing are first-order, store relation steps up
- Uses val_rel_n_step_up for each location

Proof strategy:
1. Unfold store_rel
2. For each location l with type T in Σ:
   - Get val_rel n Σ T (σ1 l) (σ2 l) from premise
   - Apply val_rel_n_step_up (since T is first-order by hypothesis)
   - Get val_rel (S n) Σ T (σ1 l) (σ2 l)
3. Reassemble into store_rel (S n)

Provide COMPLETE Coq proof. No admits.
```

---

# PART VI: PHASE 4 — FUNDAMENTALTHEOREM.V ADMITS

## 6.1 Prompt for T_Classify Admit

```
=== DEEPSEEK PROMPT: FundamentalTheorem T_Classify ===

Complete the proof for the T_Classify case in the Fundamental Theorem:

```coq
(* Context: proving fundamental theorem by induction on typing derivation *)
(* Case T_Classify: Γ ⊢ e : T → Γ ⊢ classify l e : Labeled l T *)

Lemma fundamental_classify : forall Γ e T l,
  has_type Γ e T ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ T (subst_env γ1 e) (subst_env γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TLabeled l T) 
      (subst_env γ1 (EClassify l e)) 
      (subst_env γ2 (EClassify l e)).
```

Context:
- `EClassify l e` labels expression e with security level l
- `TLabeled l T` is labeled type
- IH gives us exp_rel for e at T

Proof strategy:
1. Unfold exp_rel
2. Evaluate EClassify l e: first evaluate e to v, then wrap as VLabeled l v
3. Both sides get VLabeled l v1 / VLabeled l v2
4. From IH, v1 and v2 are val_rel at T
5. Construct val_rel at TLabeled l T

Provide COMPLETE Coq proof. No admits.
```

## 6.2 Prompt for T_Declassify Admit

```
=== DEEPSEEK PROMPT: FundamentalTheorem T_Declassify ===

Complete the proof for the T_Declassify case:

```coq
Lemma fundamental_declassify : forall Γ e T l_from l_to,
  has_type Γ e (TLabeled l_from T) ->
  can_flow l_from l_to ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ (TLabeled l_from T) (subst_env γ1 e) (subst_env γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TLabeled l_to T) 
      (subst_env γ1 (EDeclassify l_to e)) 
      (subst_env γ2 (EDeclassify l_to e)).
```

Use the logical_relation_declassify lemma (which you proved in Phase 2).

Provide COMPLETE Coq proof. No admits.
```

## 6.3 Prompt for T_Prove, T_Require, T_Grant Admits

```
=== DEEPSEEK PROMPT: FundamentalTheorem Capability Cases ===

Complete these three cases for capability/proof-carrying code:

```coq
(* T_Prove: Γ ⊢ e : T, P provable → Γ ⊢ prove P e : Proven P T *)
Lemma fundamental_prove : forall Γ e T P,
  has_type Γ e T ->
  provable P ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ T (subst_env γ1 e) (subst_env γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TProven P T) 
      (subst_env γ1 (EProve P e)) 
      (subst_env γ2 (EProve P e)).

(* T_Require: Γ ⊢ e : Proven P T → Γ ⊢ require P e : T (with P witness) *)
Lemma fundamental_require : forall Γ e T P,
  has_type Γ e (TProven P T) ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ (TProven P T) (subst_env γ1 e) (subst_env γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ T
      (subst_env γ1 (ERequire P e)) 
      (subst_env γ2 (ERequire P e)).

(* T_Grant: Γ ⊢ e : T, has capability cap → Γ ⊢ grant cap e : Granted cap T *)
Lemma fundamental_grant : forall Γ e T cap,
  has_type Γ e T ->
  has_capability cap ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ T (subst_env γ1 e) (subst_env γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TGranted cap T) 
      (subst_env γ1 (EGrant cap e)) 
      (subst_env γ2 (EGrant cap e)).
```

These are similar to T_Classify - they wrap values with proof/capability witnesses.

Provide COMPLETE Coq proofs for ALL THREE. No admits.
```

## 6.4 Prompt for Store Typing Extension Admit

```
=== DEEPSEEK PROMPT: Store Typing Extension ===

Complete this critical lemma about store typing preservation:

```coq
(* When expression steps, store typing may extend but typing is preserved *)
Lemma store_typing_extension_preserves_typing : forall Σ Σ' Γ e T,
  store_extends Σ Σ' ->
  has_type_under_store Σ Γ e T ->
  has_type_under_store Σ' Γ e T.
```

Context:
- Store extends when new locations are allocated
- Typing should be monotonic w.r.t. store extension

Proof strategy (by induction on typing derivation):
1. Most cases: IH directly
2. T_Loc case: location l has type T in Σ, need it in Σ'
   - store_extends means Σ ⊆ Σ'
   - So if Σ(l) = T, then Σ'(l) = T
3. Reference cases: use IH and store extension transitivity

Provide COMPLETE Coq proof. No admits.
```

---

# PART VII: PHASE 5 — MASTERTHEOREM.V ADMITS

## 7.1 Prompt for TProd/TSum Type Measure Induction

```
=== DEEPSEEK PROMPT: Type Measure Induction ===

Complete this proof that requires well-founded induction on type measure:

```coq
(* Type measure for well-founded induction *)
Fixpoint type_measure (T : type) : nat :=
  match T with
  | TUnit | TBool | TInt => 0
  | TProd T1 T2 => 1 + type_measure T1 + type_measure T2
  | TSum T1 T2 => 1 + type_measure T1 + type_measure T2
  | TArrow T1 _ T2 => 1 + type_measure T1 + type_measure T2
  | TRef T => 1 + type_measure T
  | TLabeled _ T => 1 + type_measure T
  | TForall _ T => 1 + type_measure T
  | _ => 1
  end.

Lemma val_rel_fo_step_up_by_measure : forall T,
  first_order_type T ->
  forall n Σ v1 v2,
    val_rel n Σ T v1 v2 ->
    val_rel (S n) Σ T v1 v2.
Proof.
  intros T.
  (* Need well-founded induction on type_measure T *)
  induction T using (well_founded_induction 
    (well_founded_ltof type type_measure)).
  (* ... *)
```

The issue is TProd and TSum require recursive calls on subtypes.

Proof strategy:
1. Use `well_founded_induction` with `type_measure`
2. IH: for all T' with type_measure T' < type_measure T, property holds
3. Case TProd T1 T2:
   - type_measure T1 < type_measure (TProd T1 T2) ✓
   - type_measure T2 < type_measure (TProd T1 T2) ✓
   - Apply IH to both components
4. Case TSum: similar

Provide COMPLETE Coq proof with well-founded induction. No admits.
```

## 7.2 Prompt for Property B Step-Up

```
=== DEEPSEEK PROMPT: Property B Step-Up ===

Complete this lemma about step-up for compound first-order types:

```coq
(* fo_compound_depth: nesting depth of TProd/TSum *)
Fixpoint fo_compound_depth (T : type) : nat :=
  match T with
  | TProd T1 T2 => 1 + max (fo_compound_depth T1) (fo_compound_depth T2)
  | TSum T1 T2 => 1 + max (fo_compound_depth T1) (fo_compound_depth T2)
  | _ => 0
  end.

Lemma property_B_step_up : forall T,
  first_order_type T ->
  forall m n Σ v1 v2,
    m > fo_compound_depth T ->
    val_rel n Σ T v1 v2 ->
    val_rel (n + m) Σ T v1 v2.
```

Context:
- If we step up by more than the compound depth, relation preserved
- This is a strengthening of val_rel_n_step_up

Proof strategy:
1. Induction on `first_order_type T`
2. Base cases (TUnit, TBool, TInt): depth is 0, any m > 0 works
3. TProd/TSum: depth is 1 + max of subtypes
   - m > 1 + max d1 d2 implies m - 1 > d1 and m - 1 > d2
   - Apply IH to components

Provide COMPLETE Coq proof. No admits.
```

## 7.3 Prompt for ST_DerefLoc Store Invariant

```
=== DEEPSEEK PROMPT: ST_DerefLoc Store Invariant ===

Complete this proof about dereference preserving closed expressions:

```coq
(* Evaluating deref of location preserves closedness *)
Lemma closed_deref_loc_step : forall σ l v σ',
  step (EDeref (ELoc l)) σ v σ' ->
  closed_expr (EDeref (ELoc l)) ->
  store_closed σ ->
  closed_expr v /\ store_closed σ'.
```

Context:
- `ELoc l` is a location literal
- Deref looks up σ(l) to get value v
- Closedness means no free variables

Proof strategy:
1. Inversion on step: must be ST_DerefLoc rule
2. σ' = σ (deref doesn't modify store)
3. v = σ(l)
4. From store_closed σ: all values in σ are closed
5. So v is closed
6. store_closed σ' = store_closed σ ✓

Provide COMPLETE Coq proof. No admits.
```

---

# PART VIII: VERIFICATION PROTOCOL

## 8.1 After Each DeepSeek Response

```
=== VERIFICATION STEPS ===

For each proof DeepSeek provides:

1. COPY the Coq code to a file: test_proof.v

2. ADD necessary imports at top:
   ```coq
   Require Import Coq.Arith.Arith.
   Require Import Coq.Lists.List.
   Require Import Lia.
   (* Add project-specific imports *)
   ```

3. RUN coqc:
   ```bash
   coqc -Q . TERAS test_proof.v
   ```

4. IF ERRORS:
   - Copy error message
   - Use Troubleshooting Prompt (Part IX)
   - Ask DeepSeek to fix

5. IF SUCCESS:
   - Copy proof to actual source file
   - Replace Axiom with Lemma + proof
   - Run full build: `make -C 02_FORMAL/coq`
```

## 8.2 Full Build Verification

```bash
#!/bin/bash
# Run after all proofs integrated

cd /workspaces/proof/02_FORMAL/coq

# Clean rebuild
make clean
make -j4

# Count remaining issues
echo "=== FINAL STATUS ==="
echo "Axioms: $(grep -r '^Axiom' . --include='*.v' | wc -l)"
echo "Admitted: $(grep -r 'Admitted\.' . --include='*.v' | wc -l)"
echo "Proven: $(grep -r '^Qed\.' . --include='*.v' | wc -l)"
```

---

# PART IX: TROUBLESHOOTING PROMPTS

## 9.1 When Proof Doesn't Compile

```
=== DEEPSEEK PROMPT: FIX COMPILATION ERROR ===

The following Coq proof has a compilation error:

```coq
[PASTE THE PROOF HERE]
```

Error message:
```
[PASTE ERROR MESSAGE HERE]
```

Please fix the proof. Requirements:
1. Must compile with coqc
2. No admits or Admitted
3. Use standard tactics: intros, destruct, induction, apply, eapply, exact, auto, lia
4. Explain what was wrong and how you fixed it
```

## 9.2 When Tactic Fails

```
=== DEEPSEEK PROMPT: ALTERNATIVE TACTIC ===

In proving this lemma:
```coq
[PASTE LEMMA STATEMENT]
```

The tactic `[TACTIC]` fails with:
```
[ERROR MESSAGE]
```

Current proof state:
```
[PASTE PROOF STATE]
```

Suggest alternative tactics to complete this proof step.
```

## 9.3 When Missing Lemma

```
=== DEEPSEEK PROMPT: AUXILIARY LEMMA ===

To prove:
```coq
[MAIN LEMMA]
```

I need an auxiliary lemma about [CONCEPT]. Please provide:
1. The lemma statement
2. Complete proof
3. Explanation of why it's needed

The auxiliary lemma should establish: [DESCRIBE WHAT YOU NEED]
```

---

# DOCUMENT SIGNATURE

```
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                                      ║
║  Document: DEEPSEEK_PROOF_ELIMINATION_MASTER_STRATEGY_v1_0_0.md                                     ║
║  Purpose: Complete prompt strategy for eliminating all axioms and admits via DeepSeek AI           ║
║  Target: 15 core axioms + 49 admits → 0                                                             ║
║                                                                                                      ║
║  Standard: ULTRA KIASU | ABSOLUTE PERFECTION | ZERO COMPROMISE                                      ║
║                                                                                                      ║
║  Estimated DeepSeek Chats: 8                                                                        ║
║  Estimated Time: 4-8 hours of prompt/response cycles                                                ║
║                                                                                                      ║
║  Success Criteria:                                                                                  ║
║  • All 15 core axioms replaced with proven lemmas                                                   ║
║  • All 49 admits completed with Qed                                                                 ║
║  • Full build passes: make -C 02_FORMAL/coq                                                         ║
║  • grep returns 0 for Axiom (core) and Admitted                                                     ║
║                                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════════╝
```

---

**END OF DEEPSEEK PROOF ELIMINATION MASTER STRATEGY**
