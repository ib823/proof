# DEEPSEEK PROMPTS — READY TO COPY/PASTE

## Instructions: Copy each prompt section to a new DeepSeek chat

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 1: MASTER CONTEXT + EXPRESSION RELATIONS (7 axioms)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 1.1 — Send this FIRST to establish context:

```
I need your help proving Coq lemmas for a type safety proof using step-indexed logical relations. This is for TERAS-LANG, a security-focused programming language.

CRITICAL REQUIREMENTS FOR ALL YOUR RESPONSES:
1. Output COMPLETE, COMPILABLE Coq code only
2. NO "admit", NO "Admitted", NO placeholders, NO "..." 
3. Every proof must end with "Qed."
4. Use standard tactics: intros, destruct, induction, apply, eapply, exact, auto, simpl, unfold, lia

Here are the key definitions you need:

```coq
(* Types *)
Inductive type : Type :=
  | TUnit : type
  | TBool : type
  | TInt : type
  | TProd : type -> type -> type
  | TSum : type -> type -> type
  | TArrow : type -> effect -> type -> type
  | TRef : type -> type
  | TLabeled : label -> type -> type.

(* Values *)
Inductive value : Type :=
  | VUnit : value
  | VBool : bool -> value
  | VInt : Z -> value
  | VPair : value -> value -> value
  | VInl : value -> value
  | VInr : value -> value
  | VLam : expr -> value
  | VLoc : loc -> value
  | VLabeled : label -> value -> value.

(* Expressions *)
Inductive expr : Type :=
  | EVal : value -> expr
  | EVar : var -> expr
  | EApp : expr -> expr -> expr
  | ELet : expr -> expr -> expr
  | EIf : expr -> expr -> expr -> expr
  | EPair : expr -> expr -> expr
  | EFst : expr -> expr
  | ESnd : expr -> expr
  | EInl : expr -> expr
  | EInr : expr -> expr
  | ECase : expr -> expr -> expr -> expr
  | ERef : expr -> expr
  | EDeref : expr -> expr
  | EAssign : expr -> expr -> expr
  | EClassify : label -> expr -> expr
  | EDeclassify : label -> expr -> expr
  | EHandle : expr -> handler -> expr.

(* Step-indexed value relation - simplified signature *)
Parameter val_rel : nat -> store_typing -> type -> value -> value -> Prop.

(* Step-indexed expression relation *)
Definition exp_rel (n : nat) (Σ : store_typing) (T : type) (e1 e2 : expr) : Prop :=
  forall k σ1 σ2,
    k <= n ->
    store_rel k Σ σ1 σ2 ->
    (forall v1 σ1' j,
      steps_to j e1 σ1 v1 σ1' -> j < k ->
      exists v2 σ2' Σ',
        steps_to j e2 σ2 v2 σ2' /\
        store_extends Σ Σ' /\
        store_rel (k - j) Σ' σ1' σ2' /\
        val_rel (k - j) Σ' T v1 v2).

(* Store relation *)
Definition store_rel (n : nat) (Σ : store_typing) (σ1 σ2 : store) : Prop :=
  forall l T,
    Σ l = Some T ->
    exists v1 v2,
      σ1 l = Some v1 /\ σ2 l = Some v2 /\
      val_rel n Σ T v1 v2.

(* First-order type predicate *)
Fixpoint first_order_type (T : type) : Prop :=
  match T with
  | TUnit | TBool | TInt => True
  | TProd T1 T2 => first_order_type T1 /\ first_order_type T2
  | TSum T1 T2 => first_order_type T1 /\ first_order_type T2
  | _ => False
  end.
```

ASSUMED HELPER LEMMAS (you can use these):
- `val_rel_mono : forall n m Σ T v1 v2, m <= n -> val_rel n Σ T v1 v2 -> val_rel m Σ T v1 v2`
- `store_rel_mono : forall n m Σ σ1 σ2, m <= n -> store_rel n Σ σ1 σ2 -> store_rel m Σ σ1 σ2`
- `store_extends_refl : forall Σ, store_extends Σ Σ`
- `store_extends_trans : forall Σ1 Σ2 Σ3, store_extends Σ1 Σ2 -> store_extends Σ2 Σ3 -> store_extends Σ1 Σ3`

I will now ask you to prove specific lemmas. For each:
1. Give me the COMPLETE Coq proof
2. Ensure it compiles
3. Brief explanation of strategy

Ready for the first lemma?
```

## PROMPT 1.2 — After DeepSeek confirms, send this:

```
Prove this lemma about expression relations for function application:

```coq
Lemma exp_rel_step1_app : forall n Σ T1 T2 eff e1 e2 e1' e2',
  exp_rel n Σ (TArrow T1 eff T2) e1 e2 ->
  exp_rel n Σ T1 e1' e2' ->
  exp_rel n Σ T2 (EApp e1 e1') (EApp e2 e2').
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

The proof should:
1. Unfold exp_rel
2. Get function values from e1/e2 using first hypothesis
3. Get argument values from e1'/e2' using second hypothesis  
4. Apply the function (using val_rel at arrow type means bodies are related when given related args)
5. Compose step counts correctly

Give me the COMPLETE proof with no admits.
```

## PROMPT 1.3 — Let binding:

```
Now prove the let binding lemma:

```coq
Lemma exp_rel_step1_let : forall n Σ T1 T2 e1 e2 e1' e2',
  exp_rel n Σ T1 e1 e2 ->
  (forall v1 v2, val_rel n Σ T1 v1 v2 -> 
   exp_rel n Σ T2 (subst v1 e1') (subst v2 e2')) ->
  exp_rel n Σ T2 (ELet e1 e1') (ELet e2 e2').
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

The ELet evaluates e1 first, then substitutes result into e1'.
Give me the COMPLETE proof.
```

## PROMPT 1.4 — Conditional:

```
Now prove the conditional lemma:

```coq
Lemma exp_rel_step1_if : forall n Σ T e_cond1 e_cond2 e_then1 e_then2 e_else1 e_else2,
  exp_rel n Σ TBool e_cond1 e_cond2 ->
  exp_rel n Σ T e_then1 e_then2 ->
  exp_rel n Σ T e_else1 e_else2 ->
  exp_rel n Σ T (EIf e_cond1 e_then1 e_else1) (EIf e_cond2 e_then2 e_else2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

Key insight: val_rel at TBool means both sides get the SAME boolean value.
Give me the COMPLETE proof.
```

## PROMPT 1.5 — Case analysis:

```
Now prove the case/sum elimination lemma:

```coq
Lemma exp_rel_step1_case : forall n Σ T1 T2 T e1 e2 e_left1 e_left2 e_right1 e_right2,
  exp_rel n Σ (TSum T1 T2) e1 e2 ->
  (forall v1 v2, val_rel n Σ T1 v1 v2 -> 
   exp_rel n Σ T (subst v1 e_left1) (subst v2 e_left2)) ->
  (forall v1 v2, val_rel n Σ T2 v1 v2 -> 
   exp_rel n Σ T (subst v1 e_right1) (subst v2 e_right2)) ->
  exp_rel n Σ T (ECase e1 e_left1 e_right1) (ECase e2 e_left2 e_right2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

val_rel at TSum means both are VInl or both are VInr (same constructor).
Give me the COMPLETE proof.
```

## PROMPT 1.6 — Projections:

```
Now prove both projection lemmas:

```coq
Lemma exp_rel_step1_fst : forall n Σ T1 T2 e1 e2,
  exp_rel n Σ (TProd T1 T2) e1 e2 ->
  exp_rel n Σ T1 (EFst e1) (EFst e2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.

Lemma exp_rel_step1_snd : forall n Σ T1 T2 e1 e2,
  exp_rel n Σ (TProd T1 T2) e1 e2 ->
  exp_rel n Σ T2 (ESnd e1) (ESnd e2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

val_rel at TProd gives us related components. Give me BOTH complete proofs.
```

## PROMPT 1.7 — Effect handler:

```
Now prove the effect handler lemma (most complex):

```coq
(* Assume handler_rel is defined appropriately *)
Lemma exp_rel_step1_handle : forall n Σ T eff e1 e2 h1 h2,
  exp_rel n Σ T e1 e2 ->
  handler_rel n Σ eff T h1 h2 ->
  exp_rel n Σ T (EHandle e1 h1) (EHandle e2 h2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

Two cases:
1. e1/e2 return normally without effects - use first premise
2. e1/e2 perform effect - handler_rel gives us related handler applications

Give me the COMPLETE proof.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 2: LOGICAL RELATION AXIOMS (4 axioms)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 2.1 — Start with context, then reference creation:

```
I'm continuing to prove lemmas for step-indexed logical relations in Coq. Use the same definitions I gave before (val_rel, exp_rel, store_rel for a typed lambda calculus with references).

Prove the reference creation lemma:

```coq
Lemma logical_relation_ref : forall n Σ T e1 e2,
  exp_rel n Σ T e1 e2 ->
  exp_rel n Σ (TRef T) (ERef e1) (ERef e2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

ERef e allocates a fresh location with value of e.
- Evaluate e1/e2 to values v1/v2
- Allocate fresh locations l1/l2
- Extend store typing Σ to Σ' with new mappings
- Show locations are related at TRef T

Give me the COMPLETE Coq proof with Qed. No admits.
```

## PROMPT 2.2 — Dereference:

```
Now prove dereference:

```coq
Lemma logical_relation_deref : forall n Σ T e1 e2,
  exp_rel n Σ (TRef T) e1 e2 ->
  exp_rel n Σ T (EDeref e1) (EDeref e2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

EDeref looks up the location in the store.
- Get location values VLoc l1, VLoc l2 from premise
- Look up σ1(l1) and σ2(l2)
- From store_rel, these values are related

Give me the COMPLETE proof.
```

## PROMPT 2.3 — Assignment:

```
Now prove assignment:

```coq
Lemma logical_relation_assign : forall n Σ T e_ref1 e_ref2 e_val1 e_val2,
  exp_rel n Σ (TRef T) e_ref1 e_ref2 ->
  exp_rel n Σ T e_val1 e_val2 ->
  exp_rel n Σ TUnit (EAssign e_ref1 e_val1) (EAssign e_ref2 e_val2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

EAssign updates store and returns unit.
- Get locations and values
- Update stores: σ1' = σ1[l1 := v1], σ2' = σ2[l2 := v2]
- Show store_rel preserved
- Return unit (trivially related)

Give me the COMPLETE proof.
```

## PROMPT 2.4 — Declassify:

```
Now prove declassification:

```coq
Lemma logical_relation_declassify : forall n Σ l_from l_to T e1 e2,
  exp_rel n Σ (TLabeled l_from T) e1 e2 ->
  can_flow l_from l_to ->
  exp_rel n Σ (TLabeled l_to T) (EDeclassify l_to e1) (EDeclassify l_to e2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

EDeclassify changes security label.
- Get labeled values VLabeled l_from v1, VLabeled l_from v2
- Underlying values v1, v2 are related at T
- Result is VLabeled l_to v1, VLabeled l_to v2
- Still related at TLabeled l_to T

Give me the COMPLETE proof.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 3: VALUE/STORE RELATION AXIOMS (4 axioms)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 3.1 — First-order step-up:

```
I need to prove step-up lemmas for step-indexed logical relations.

```coq
(* First-order types have no functions, so val_rel is step-independent *)
Lemma val_rel_n_step_up : forall n Σ T v1 v2,
  first_order_type T ->
  val_rel n Σ T v1 v2 ->
  val_rel (S n) Σ T v1 v2.
Proof.
  (* YOUR COMPLETE PROOF HERE - use induction on first_order_type T *)
Qed.
```

first_order_type T means T is TUnit, TBool, TInt, or TProd/TSum of first-order types.

Proof by induction on `first_order_type T`:
- Base cases: val_rel is just equality, step doesn't matter
- TProd: apply IH to components
- TSum: case on VInl/VInr, apply IH

Give me the COMPLETE proof.
```

## PROMPT 3.2 — Lambda cumulative:

```
Prove downward closure for arrow types:

```coq
Lemma val_rel_n_lam_cumulative : forall n m Σ T1 eff T2 e1 e2,
  m <= n ->
  val_rel n Σ (TArrow T1 eff T2) (VLam e1) (VLam e2) ->
  val_rel m Σ (TArrow T1 eff T2) (VLam e1) (VLam e2).
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

val_rel at arrow says: for all k < n, related args give related results.
For m <= n: for all k < m, we have k < n, so same property holds.

Give me the COMPLETE proof.
```

## PROMPT 3.3 — Value relation conversions:

```
Prove these two conversion lemmas:

```coq
Lemma val_rel_n_to_val_rel : forall n Σ T v1 v2,
  val_rel (S n) Σ T v1 v2 ->
  val_rel n Σ T v1 v2.
Proof.
  (* By induction on T, using monotonicity *)
Qed.

Lemma val_rel_at_type_to_val_rel_ho : forall n Σ T v1 v2,
  val_rel n Σ T v1 v2 ->
  forall m, m <= n -> val_rel m Σ T v1 v2.
Proof.
  (* Use val_rel_n_to_val_rel repeatedly or induction *)
Qed.
```

Give me BOTH complete proofs.
```

## PROMPT 3.4 — Store relation step-up:

```
Prove store relation steps up when all types are first-order:

```coq
Lemma store_rel_n_step_up : forall n Σ σ1 σ2,
  (forall l T, Σ l = Some T -> first_order_type T) ->
  store_rel n Σ σ1 σ2 ->
  store_rel (S n) Σ σ1 σ2.
Proof.
  (* YOUR COMPLETE PROOF HERE *)
Qed.
```

For each location l with type T:
- Get val_rel n Σ T (σ1 l) (σ2 l) from premise
- T is first-order by hypothesis
- Apply val_rel_n_step_up
- Get val_rel (S n) Σ T (σ1 l) (σ2 l)

Give me the COMPLETE proof.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 4: FUNDAMENTAL THEOREM ADMITS (Part 1)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 4.1 — Security constructs:

```
I need to complete proofs for the Fundamental Theorem of logical relations. These are cases for security constructs.

```coq
(* Environment relation *)
Definition env_rel (n : nat) (Σ : store_typing) (Γ : context) 
                   (γ1 γ2 : substitution) : Prop :=
  forall x T, Γ x = Some T -> val_rel n Σ T (γ1 x) (γ2 x).

(* Fundamental theorem statement - we're proving cases *)
(* If Γ ⊢ e : T, then for related environments, substituted expressions are related *)

Lemma fundamental_classify : forall Γ l e T,
  has_type Γ e T ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ T (apply_subst γ1 e) (apply_subst γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TLabeled l T) 
      (apply_subst γ1 (EClassify l e)) 
      (apply_subst γ2 (EClassify l e)).
Proof.
  (* EClassify l e evaluates e to v, then wraps as VLabeled l v *)
  (* Use IH to get v1 ~ v2, then show VLabeled l v1 ~ VLabeled l v2 *)
Qed.

Lemma fundamental_declassify : forall Γ l_from l_to e T,
  has_type Γ e (TLabeled l_from T) ->
  can_flow l_from l_to ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ (TLabeled l_from T) (apply_subst γ1 e) (apply_subst γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TLabeled l_to T) 
      (apply_subst γ1 (EDeclassify l_to e)) 
      (apply_subst γ2 (EDeclassify l_to e)).
Proof.
  (* Use logical_relation_declassify *)
Qed.
```

Give me BOTH complete proofs.
```

## PROMPT 4.2 — Capability constructs:

```
Now the capability/proof-carrying code cases:

```coq
Lemma fundamental_prove : forall Γ P e T,
  has_type Γ e T ->
  provable P ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ T (apply_subst γ1 e) (apply_subst γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TProven P T) 
      (apply_subst γ1 (EProve P e)) 
      (apply_subst γ2 (EProve P e)).
Proof.
  (* EProve P e wraps value with proof witness *)
Qed.

Lemma fundamental_require : forall Γ P e T,
  has_type Γ e (TProven P T) ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ (TProven P T) (apply_subst γ1 e) (apply_subst γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ T
      (apply_subst γ1 (ERequire P e)) 
      (apply_subst γ2 (ERequire P e)).
Proof.
  (* ERequire P e unwraps proven value *)
Qed.

Lemma fundamental_grant : forall Γ cap e T,
  has_type Γ e T ->
  has_capability cap ->
  (forall n Σ γ1 γ2, env_rel n Σ Γ γ1 γ2 -> 
   exp_rel n Σ T (apply_subst γ1 e) (apply_subst γ2 e)) ->
  forall n Σ γ1 γ2,
    env_rel n Σ Γ γ1 γ2 ->
    exp_rel n Σ (TGranted cap T) 
      (apply_subst γ1 (EGrant cap e)) 
      (apply_subst γ2 (EGrant cap e)).
Proof.
  (* EGrant cap e wraps value with capability *)
Qed.
```

Give me ALL THREE complete proofs.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 5: FUNDAMENTAL THEOREM ADMITS (Part 2)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 5.1 — Store typing extension:

```
Prove that typing is preserved under store extension:

```coq
Lemma store_typing_extension_preserves_typing : forall Σ Σ' Γ e T,
  store_extends Σ Σ' ->
  has_type_under_store Σ Γ e T ->
  has_type_under_store Σ' Γ e T.
Proof.
  intros Σ Σ' Γ e T Hext Hty.
  induction Hty.
  (* By induction on typing derivation *)
  (* Most cases: apply IH *)
  (* T_Loc case: Σ(l) = T implies Σ'(l) = T by store_extends *)
Qed.
```

store_extends Σ Σ' means: forall l T, Σ l = Some T -> Σ' l = Some T

Give me the COMPLETE proof by induction on has_type_under_store.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 6: MASTER THEOREM ADMITS (Part 1)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 6.1 — Type measure induction:

```
I need to prove a lemma using well-founded induction on type measure:

```coq
Fixpoint type_measure (T : type) : nat :=
  match T with
  | TUnit | TBool | TInt => 0
  | TProd T1 T2 => 1 + type_measure T1 + type_measure T2
  | TSum T1 T2 => 1 + type_measure T1 + type_measure T2
  | TArrow T1 _ T2 => 1 + type_measure T1 + type_measure T2
  | TRef T => 1 + type_measure T
  | TLabeled _ T => 1 + type_measure T
  | _ => 1
  end.

Lemma val_rel_fo_step_up_by_measure : forall T,
  first_order_type T ->
  forall n Σ v1 v2,
    val_rel n Σ T v1 v2 ->
    val_rel (S n) Σ T v1 v2.
Proof.
  intro T.
  induction T using (well_founded_induction 
    (well_founded_ltof type type_measure)).
  intros Hfo n Σ v1 v2 Hrel.
  destruct T; simpl in Hfo; try contradiction.
  (* Cases for TUnit, TBool, TInt, TProd, TSum *)
Qed.
```

For TProd T1 T2:
- type_measure T1 < type_measure (TProd T1 T2) 
- type_measure T2 < type_measure (TProd T1 T2)
- So we can apply IH

Give me the COMPLETE proof using well_founded_induction.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 7: MASTER THEOREM ADMITS (Part 2)
# ═══════════════════════════════════════════════════════════════════════════════

## PROMPT 7.1 — Property B step-up:

```
Prove this stronger step-up property:

```coq
Fixpoint fo_compound_depth (T : type) : nat :=
  match T with
  | TProd T1 T2 => 1 + max (fo_compound_depth T1) (fo_compound_depth T2)
  | TSum T1 T2 => 1 + max (fo_compound_depth T1) (fo_compound_depth T2)
  | _ => 0
  end.

Lemma property_B_step_up : forall T,
  first_order_type T ->
  forall m n Σ v1 v2,
    m > fo_compound_depth T ->
    val_rel n Σ T v1 v2 ->
    val_rel (n + m) Σ T v1 v2.
Proof.
  intros T Hfo.
  induction Hfo; intros m n Σ v1 v2 Hdepth Hrel.
  (* Base cases: depth is 0, so any m > 0 works *)
  (* TProd/TSum: use IH on components *)
Qed.
```

Give me the COMPLETE proof.
```

## PROMPT 7.2 — Deref store invariant:

```
Prove closedness is preserved through dereference:

```coq
Lemma closed_deref_loc_step : forall σ l v σ',
  step (EDeref (ELoc l)) σ v σ' ->
  closed_expr (EDeref (ELoc l)) ->
  store_closed σ ->
  closed_expr v /\ store_closed σ'.
Proof.
  intros σ l v σ' Hstep Hclosed Hstore.
  (* Inversion on Hstep: must be ST_DerefLoc *)
  (* σ' = σ, v = σ(l) *)
  (* From store_closed σ, σ(l) is closed *)
Qed.
```

Give me the COMPLETE proof.
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# CHAT 8: VERIFICATION AND FIXES
# ═══════════════════════════════════════════════════════════════════════════════

Use this chat for fixing any proofs that don't compile.

## TEMPLATE FOR FIXES:

```
This Coq proof has an error:

```coq
[PASTE PROOF]
```

Error:
```
[PASTE ERROR]
```

Fix the proof. Requirements:
- Must compile
- No admits
- Explain what was wrong
```

---

# FINAL VERIFICATION SCRIPT

After integrating all proofs, run:

```bash
cd /workspaces/proof/02_FORMAL/coq
make clean && make -j4

echo "=== FINAL COUNT ==="
echo "Remaining Axioms (should exclude compliance): $(grep -r '^Axiom' . --include='*.v' | grep -v compliance | grep -v security | grep -v gdpr | grep -v hipaa | grep -v pci | grep -v cmmc | wc -l)"
echo "Remaining Admitted: $(grep -r 'Admitted\.' . --include='*.v' | wc -l)"
echo "Total Proven: $(grep -r '^Qed\.' . --include='*.v' | wc -l)"
```

Target: 0 core axioms, 0 admits remaining.
